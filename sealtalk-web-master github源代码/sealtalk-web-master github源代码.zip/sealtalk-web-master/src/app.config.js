window.__sealtalk_config={
  serverUrl:"***",
  appkey:"***"
}
